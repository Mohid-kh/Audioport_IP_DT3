#include "cdc_unit.h"


#if defined(MTI_SYSTEMC)
SC_MODULE_EXPORT(cdc_unit);
#endif
