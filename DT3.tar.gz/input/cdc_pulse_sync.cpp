#include "cdc_pulse_sync.h"

#if defined(MTI_SYSTEMC)
SC_MODULE_EXPORT(cdc_pulse_sync);
#endif
