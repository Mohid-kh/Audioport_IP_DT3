#include "cdc_2ff_sync.h"

#if defined(MTI_SYSTEMC)
SC_MODULE_EXPORT(cdc_2ff_sync);
#endif
